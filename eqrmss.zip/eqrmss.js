// ============================================================
// EQRMSS System Bootstrap
// EverQuest - Rolemaster Standard System
// Foundry VTT V13 / V14 Compatible
// ============================================================

import {
    registerEQRMSSSettings,
    registerEQRMSSDocuments,
    registerEQRMSSDataLoaders,
    loadEQRMSSTemplates,
    registerEQRMSSHooks,
    initializeEQRMSSSubsystems,
    initializeEQRMSSDataLoaders
} from "./module/initialization/index.js";

import "./module/config.js";
import { registerEQRMSSSheets } from "./module/initialization/register-sheets.js";
import "./module/apps/eqrmss-character-creation-wizard.js";
import { EQRMSSGeography } from "./module/data/geography/geography-loader.js";
import { EQRMSSSceneRegistry } from "./module/data/geography/scene-registry.js";

// RMSS Engines
import "./module/data/stats/rmss-stat-rolling.js";
import "./module/data/stats/rmss-point-buy.js";
import "./module/data/stats/rmss-derived-values.js";
import "./module/data/stats/rmss-skill-categories.js";
import "./module/data/stats/rmss-skill-costs.js";
import "./module/data/stats/rmss-stat-bonus.js";
import "./module/data/stats/rmss-combat-round-engine.js";
import "./module/data/stats/rmss-spell-resolution-engine.js";
import "./module/data/stats/rmss-skill-check-engine.js";
import "./module/data/stats/rmss-weapon-damage-engine.js";
import "./module/data/stats/rmss-progression-engine.js";

// EQRMSS Skill Engine (new subsystem)
import { initializeSkillEngine } from "./module/utils/skills/index.js";

// ============================================================
// INIT
// ============================================================
Hooks.once("init", async function () {
    console.log("EQRMSS | Initializing");

    try {
        registerEQRMSSSettings();
        registerEQRMSSDocuments();

        await loadEQRMSSTemplates();

        registerEQRMSSDataLoaders();
        registerEQRMSSHooks();

        await EQRMSSGeography.loadAll();
        await EQRMSSSceneRegistry.registerAllScenes();

        console.log("EQRMSS | Initialization complete");
    } catch (error) {
        console.error("EQRMSS | Initialization failed", error);
    }
});

// ============================================================
// READY
// ============================================================
Hooks.once("ready", async function () {
    console.log("EQRMSS | Starting ready pipeline");

    try {
        await initializeEQRMSSDataLoaders();
        await initializeEQRMSSSubsystems();

        // --------------------------------------------
        // Skill Engine Initialization
        // --------------------------------------------
        try {
            const skillsPack = game.packs.get("eqrmss.skills");
            const categoriesPack = game.packs.get("eqrmss.skill-categories");
            const metadataPack = game.packs.get("eqrmss.skill-metadata");
            const professionCostsPack = game.packs.get("eqrmss.profession-skill-costs");

            const skills = skillsPack ? await skillsPack.getDocuments() : [];
            const categories = categoriesPack ? await categoriesPack.getDocuments() : [];
            const metadata = metadataPack ? await metadataPack.getDocuments() : [];
            const professionCosts = professionCostsPack ? await professionCostsPack.getDocuments() : [];

            const roller = {
                roll: (formula) => new Roll(formula).roll({ async: false })
            };

            initializeSkillEngine({
                skills,
                categories,
                metadata,
                professionCosts,
                roller
            });

            console.log("EQRMSS | Skill Engine initialized");
        } catch (skillError) {
            console.error("EQRMSS | Skill Engine failed to initialize", skillError);
        }

        // --------------------------------------------
        // Geography
        // --------------------------------------------
        try {
            await EQRMSSGeography.loadAll();
            console.log("EQRMSS | Geography loaded");
            await EQRMSSSceneRegistry.registerAllScenes();
            console.log("EQRMSS | Geography scenes registered");
        } catch (geoError) {
            console.error("EQRMSS | Geography failed to load", geoError);
        }

        registerEQRMSSSheets();

        console.log("EQRMSS | Ready");
    } catch (error) {
        console.error("EQRMSS | Ready pipeline failed", error);
        ui.notifications?.error("EQRMSS failed during startup. Check console.");
    }
});
