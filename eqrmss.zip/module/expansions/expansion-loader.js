/**
 * ============================================================
 * EQRMSS Expansion Loader
 * ============================================================
 *
 * Schema: 2.0
 *
 * Responsibilities:
 * - Load expansion registry
 * - Load expansion manifests
 * - Validate expansion data
 * - Provide registry helper methods
 *
 * Does NOT:
 * - Manage active expansion
 * - Apply unlock rules
 * - Resolve race/class access
 *
 * ============================================================
 */

const MODULE_ID = "eqrmss";

export class EQRMSSExpansionLoader {

  static INDEX_PATH =
    "systems/eqrmss/module/data/expansions/index.json";

  static async load() {

    const index =
      await this._loadIndex();

    const expansions = {};

    for (const id of index.expansions) {
      expansions[id] =
        await this._loadExpansion(id);
    }

    this._validateProgression(
      index,
      expansions
    );

    return {
      index,
      expansions
    };
  }

  static async _loadIndex() {

    const response =
      await fetch(this.INDEX_PATH);

    if (!response.ok) {

      throw new Error(
        `Failed to load expansion registry: ${this.INDEX_PATH}`
      );
    }

    const index =
      await response.json();

    this._validateIndex(index);

    return index;
  }

  static async _loadExpansion(id) {

    const path =
      `systems/eqrmss/module/data/expansions/${id}.json`;

    const response =
      await fetch(path);

    if (!response.ok) {

      throw new Error(
        `Failed to load expansion manifest: ${id}`
      );
    }

    const manifest =
      await response.json();

    this._validateManifest(manifest);

    return manifest;
  }

  static _validateIndex(index) {

    if (index.schemaVersion !== "2.0") {

      throw new Error(
        `Unsupported expansion registry schema: ${index.schemaVersion}`
      );
    }

    if (!Array.isArray(index.expansions)) {

      throw new Error(
        "Registry missing expansions array."
      );
    }

    if (!Array.isArray(index.progression)) {

      throw new Error(
        "Registry missing progression array."
      );
    }

    if (!index.milestones) {

      throw new Error(
        "Registry missing milestones section."
      );
    }
  }

  static _validateManifest(manifest) {

    const required = [
      "id",
      "name",
      "order",
      "content"
    ];

    for (const field of required) {

      if (!(field in manifest)) {

        throw new Error(
          `${manifest.id ?? "unknown"} missing required field: ${field}`
        );
      }
    }

    if (manifest.schemaVersion !== "2.0") {

      throw new Error(
        `Unsupported schema version for ${manifest.id}`
      );
    }
  }

  static _validateProgression(
    index,
    expansions
  ) {

    for (const entry of index.progression) {

      const manifest =
        expansions[entry.id];

      if (!manifest) {

        throw new Error(
          `Missing expansion referenced by registry: ${entry.id}`
        );
      }

      if (manifest.order !== entry.order) {

        throw new Error(
          `Order mismatch:
           ${entry.id}
           registry=${entry.order}
           manifest=${manifest.order}`
        );
      }
    }
  }

  /**
   * ==========================================================
   * Registry Helpers
   * ==========================================================
   */

  static getExpansionIds(index) {
    return [...index.expansions];
  }

  static getCurrentExpansion(index) {
    return index.currentExpansion;
  }

  static getDefaultExpansion(index) {
    return index.defaultExpansion;
  }

  static getMinimumExpansion(index) {
    return index.minimumSupportedExpansion;
  }

  static getMaximumExpansion(index) {
    return index.maximumSupportedExpansion;
  }

  static getProgression(index) {
    return [...index.progression];
  }

  static getProgressionMap(index) {

    return new Map(
      index.progression.map(entry => [
        entry.id,
        entry.order
      ])
    );
  }

  static getExpansionOrder(
    index,
    expansionId
  ) {

    const entry =
      index.progression.find(
        e => e.id === expansionId
      );

    return entry?.order ?? -1;
  }

  static getExpansionByOrder(
    index,
    order
  ) {

    const entry =
      index.progression.find(
        e => e.order === order
      );

    return entry?.id ?? null;
  }

  /**
   * ==========================================================
   * Milestone Helpers
   * ==========================================================
   */

  static getMilestones(index) {

    return foundry.utils.deepClone(
      index.milestones
    );
  }

  static getMilestone(
    index,
    name
  ) {

    return (
      index.milestones?.[name] ??
      null
    );
  }

  static getFirstAaExpansion(index) {
    return index.milestones?.firstAaExpansion ?? null;
  }

  static getFirstAdvancedAaExpansion(index) {
    return index.milestones?.firstAdvancedAaExpansion ?? null;
  }

  static getFirstPlayableRaceExpansion(index) {
    return index.milestones?.firstPlayableRaceExpansion ?? null;
  }

  static getFirstExpansionClassUnlock(index) {
    return index.milestones?.firstExpansionClassUnlock ?? null;
  }

  static getSecondExpansionClassUnlock(index) {
    return index.milestones?.secondExpansionClassUnlock ?? null;
  }

  /**
   * ==========================================================
   * Manifest Helpers
   * ==========================================================
   */

  static getExpansion(
    expansions,
    id
  ) {

    return expansions[id] ?? null;
  }

  static hasExpansion(
    expansions,
    id
  ) {

    return !!expansions[id];
  }

  static isPlaceholderExpansion(
    expansions,
    id
  ) {

    return (
      expansions[id]?.placeholderRegions === true
    );
  }

  static getExpansionWorlds(
    expansions,
    id
  ) {

    return expansions[id]?.content?.worlds ?? [];
  }

  static getExpansionContinents(
    expansions,
    id
  ) {

    return expansions[id]?.content?.continents ?? [];
  }

  static getExpansionRealms(
    expansions,
    id
  ) {

    return expansions[id]?.content?.realms ?? [];
  }

  static getExpansionRegions(
    expansions,
    id
  ) {

    return expansions[id]?.content?.regions ?? [];
  }

  static getExpansionRaces(
    expansions,
    id
  ) {

    return expansions[id]?.content?.races ?? [];
  }

  static getExpansionClasses(
    expansions,
    id
  ) {

    return expansions[id]?.content?.classes ?? [];
  }

  /**
   * ==========================================================
   * Progression Comparison
   * ==========================================================
   */

  static isExpansionAtOrAfter(
    index,
    sourceId,
    targetId
  ) {

    return (
      this.getExpansionOrder(index, sourceId) >=
      this.getExpansionOrder(index, targetId)
    );
  }

  static isExpansionBefore(
    index,
    sourceId,
    targetId
  ) {

    return (
      this.getExpansionOrder(index, sourceId) <
      this.getExpansionOrder(index, targetId)
    );
  }

  static getExpansionRange(
    index,
    startId,
    endId
  ) {

    const start =
      this.getExpansionOrder(index, startId);

    const end =
      this.getExpansionOrder(index, endId);

    return index.progression
      .filter(
        p =>
          p.order >= start &&
          p.order <= end
      )
      .map(
        p => p.id
      );
  }
}