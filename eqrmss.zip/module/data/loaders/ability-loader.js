// ============================================================
// EQRMSS Ability Loader (Array File Version)
// ------------------------------------------------------------
// Loads ability data from JSON files that each contain
// an ARRAY of ability objects.
//
// Example:
//   abilities/index.json:
//     {
//       "files": [
//         "bard.json",
//         "cleric.json",
//         "warrior.json"
//       ]
//     }
//
//   abilities/bard.json:
//     [
//       { "_id": "eqrmss-bard-ability-001", ... },
//       { "_id": "eqrmss-bard-ability-002", ... }
//     ]
//
// ============================================================
console.warn("EQRMSS | USING CORRECT ablity-loader.js");


const ABILITY_ROOT = "systems/eqrmss/module/data/abilities";

export class AbilityLoader {

    // ------------------------------------------------------------
    // PUBLIC ENTRY POINT
    // ------------------------------------------------------------
    static async load() {
        return await AbilityLoader.loadAbilities();
    }

    // ------------------------------------------------------------
    // LOAD ALL ABILITY FILES
    // ------------------------------------------------------------
    static async loadAbilities() {

        CONFIG.EQRMSS ??= {};
        CONFIG.EQRMSS.abilities ??= {};

        // Load index.json
        const index = await this.loadJSON(`${ABILITY_ROOT}/index.json`);

        if (!index || !index.files) {
            console.warn("EQRMSS | Ability index missing or invalid");
            return [];
        }

        const loaded = [];

        // Load each ability file listed in index.json
        for (const file of index.files) {

            const path = `${ABILITY_ROOT}/${file}`;
            const abilitiesArray = await this.loadJSON(path);

            if (!abilitiesArray) {
                console.warn(`EQRMSS | Ability file missing or invalid: ${file}`);
                continue;
            }

            // Determine the list of ability objects in the file.
            let abilitiesList = null;
            if (Array.isArray(abilitiesArray)) {
                abilitiesList = abilitiesArray;
            } else if (abilitiesArray && Array.isArray(abilitiesArray.items)) {
                // Files that wrap abilities under an "items" key.
                abilitiesList = abilitiesArray.items;
            } else if (typeof abilitiesArray === 'object') {
                // Gather candidate entries and pick those that resemble ability objects.
                const candidates = Object.values(abilitiesArray).filter(v => v && typeof v === 'object');
                const abilityLike = candidates.filter(v => ('name' in v) && (('system' in v) || v.type === 'ability'));
                if (abilityLike.length) abilitiesList = abilityLike;
            }

            if (!Array.isArray(abilitiesList)) {
                console.warn(`EQRMSS | Ability file invalid (expected array/object with abilities): ${file}`);
                continue;
            }

            const fileBase = file.replace(/\.json$/i, '').replace(/[^a-z0-9]+/ig, '-').toLowerCase();
            for (let idx = 0; idx < abilitiesList.length; idx++) {
                const ability = abilitiesList[idx];

                // Auto-generate an _id if missing
                if (!ability?._id && !ability?.id) {
                    ability._id = `eqrmss-${fileBase}-${String(idx+1).padStart(3, '0')}`;
                    console.info(`EQRMSS | Generated _id for ability in ${file}: ${ability._id}`);
                }

                if (!ability?._id) {
                    console.warn(`EQRMSS | Ability missing _id in file: ${file}`);
                    continue;
                }

                CONFIG.EQRMSS.abilities[ability._id] = ability;
                loaded.push(ability);
            }
        }

        console.log(`EQRMSS | Loaded ${loaded.length} abilities`);
        return loaded;
    }

    // ------------------------------------------------------------
    // JSON FETCH WRAPPER
    // ------------------------------------------------------------
    static async loadJSON(path) {
        try {
            const response = await fetch(path);

            if (!response.ok) {
                console.warn("EQRMSS | Ability file missing", path);
                return null;
            }

            return await response.json();
        }
        catch (error) {
            console.error("EQRMSS | Ability JSON failed", path, error);
            return null;
        }
    }

    // ------------------------------------------------------------
    // ACCESSORS
    // ------------------------------------------------------------
    static getAbility(id) {
        return CONFIG.EQRMSS?.abilities?.[id] ?? null;
    }

    static getAbilities() {
        return Object.values(CONFIG.EQRMSS?.abilities ?? {});
    }

    static getByType(type) {
        return this.getAbilities().filter(a => a.type === type);
    }

    static getClassAbilities(className) {
        return this.getAbilities().filter(a => a.system?.class === className);
    }

    static getAbilitiesByLevel(level) {
        return this.getAbilities().filter(a => (a.system?.level ?? 1) <= level);
    }

    static searchAbilities(query) {
        if (!query) return [];
        query = query.toLowerCase();

        return this.getAbilities().filter(a =>
            a.name?.toLowerCase().includes(query) ||
            a.system?.description?.toLowerCase().includes(query)
        );
    }
}

// ------------------------------------------------------------
// PUBLIC API
// ------------------------------------------------------------
export async function loadAbilities() {
    return await AbilityLoader.load();
}

export default AbilityLoader;
