// ============================================================
// EQRMSS Race Loader
//
// Foundry VTT V13 / V14
//
// Loads EverQuest race definitions from filesystem JSON.
//
// Public API:
//     loadRaces()
//     RaceLoader
// ============================================================

const RACE_ROOT = "systems/eqrmss/module/data/races";


// ============================================================
// RACE LOADER
// ============================================================

export class RaceLoader {

    static async load() {

        try {

            const indexPath =
                `${RACE_ROOT}/index.json`;

            const response =
                await fetch(indexPath);

            if (!response.ok) {

                console.warn(
                    "EQRMSS | Race index not found",
                    indexPath
                );

                return [];

            }

            const index =
                await response.json();

            const names =
                Array.isArray(index?.races)
                    ? index.races
                    : [];

            const races = [];

            for (const name of names) {

                if (!name)
                    continue;

                const path =
                    `${RACE_ROOT}/${name}.json`;

                try {

                    const raceResponse =
                        await fetch(path);

                    if (!raceResponse.ok) {

                        console.warn(
                            "EQRMSS | Race file not found",
                            path
                        );

                        continue;

                    }

                    const data =
                        await raceResponse.json();

                    if (!data)
                        continue;

                    races.push(data);

                }
                catch (error) {

                    console.error(
                        `EQRMSS | Failed loading race ${name}`,
                        error
                    );

                }

            }

            CONFIG.EQRMSS ??= {};

            CONFIG.EQRMSS.races =
                Object.fromEntries(
                    races.map(
                        race => [
                            race.id ?? race.key ?? race.name,
                            race
                        ]
                    )
                );

            console.info(
                "EQRMSS | Races loaded",
                races.length
            );

            return races;

        }
        catch (error) {

            console.error(
                "EQRMSS | Failed to load races",
                error
            );

            CONFIG.EQRMSS ??= {};
            CONFIG.EQRMSS.races ??= {};

            return [];

        }

    }

}


// ============================================================
// PUBLIC API
// ============================================================

export async function loadRaces() {

    return await RaceLoader.load();

}


// ============================================================
// LEGACY COMPATIBILITY
// ============================================================

export async function loadEQRMSSRaces() {

    return await RaceLoader.load();

}


export default RaceLoader;