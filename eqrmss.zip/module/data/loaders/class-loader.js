// ============================================================
// EQRMSS Consolidated Class Loader
//
// Loads EverQuest class definitions from filesystem JSON and
// consolidates per-class data (abilities, features, progressions,
// profiles, spells, songs, etc.) into CONFIG.EQRMSS.* maps.
//
// Foundry VTT V13 / V14
//
// Public API:
//      loadClasses()
//      ClassLoader
// ============================================================

const CLASS_ROOT = "systems/eqrmss/module/data/classes";

// Helper function to safely insert into configuration maps
function put(map, key, value) {
  if (!key) return;
  map[key] = value;
}

function normalizeClassDefinition(raw) {
  const classData = foundry.utils.deepClone(raw);
  const roles = Array.isArray(classData.roles)
    ? classData.roles
    : classData.role
      ? [classData.role.primary, classData.role.secondary].filter(Boolean)
      : [];
  const description = typeof classData.description === "string"
    ? { short: classData.description, long: classData.description }
    : (classData.description ?? {});
  const primaryStats = classData.roleMaster?.primaryStats
    ?? classData.stats?.primary
    ?? classData.stats?.prime_requisites
    ?? [];

  classData.type ??= "class";
  classData.archetype ??= classData.roleMaster?.profession?.toLowerCase() ?? "pending";
  classData.roles ??= roles;
  classData.primaryRole ??= roles[0] ?? classData.role?.primary ?? "pending";
  classData.secondaryRoles ??= roles.slice(1);
  classData.description = description;

  classData.eqrmss ??= {};
  classData.eqrmss.schemaVersion ??= 1;
  classData.eqrmss.identity ??= {
    key: classData.key ?? classData.id,
    name: classData.name,
    primaryStats,
    designStatus: "content-defined; unresolved mechanics remain pending"
  };
  classData.eqrmss.classification ??= {
    archetype: classData.archetype,
    roles: classData.roles,
    primaryRole: classData.primaryRole,
    secondaryRoles: classData.secondaryRoles
  };
  classData.eqrmss.resources = classData.eqrmss.resources ?? classData.resources ?? {
    primary: "pending",
    secondary: [],
    recovery: "pending"
  };
  classData.eqrmss.combat = classData.eqrmss.combat ?? {
    armor: classData.armor ?? "pending",
    weapons: classData.weapons ?? "pending",
    style: classData.combat?.attackStyle ?? "pending",
    specialRules: []
  };
  classData.eqrmss.magic = classData.eqrmss.magic ?? {
    spellcasting: classData.spellRealm ? "available" : "pending",
    spellLists: classData.profiles?.spells ?? [],
    restrictions: []
  };
  classData.eqrmss.features = classData.eqrmss.features ?? {
    passive: classData.classFeatures ?? [],
    active: classData.abilities ?? [],
    triggered: [],
    conditional: []
  };
  classData.eqrmss.extensions = classData.eqrmss.extensions ?? {
    songs: classData.profiles?.songs ?? [],
    pets: classData.profiles?.pet
      ? [classData.profiles.pet]
      : (classData.petProgression ? [classData.petProgression] : []),
    disciplines: classData.disciplines ?? [],
    deity: classData.deityAffinity ?? classData.deityRestrictions ?? null
  };
  classData.eqrmss.pending ??= [
    "exact development-point costs",
    "exact level-by-level progression",
    "exact spell-list IDs",
    "exact Rolemaster attack tables",
    "exact resource formulas"
  ];

  return classData;
}

export class ClassLoader {
  static async load() {
    try {
      const indexPath = `${CLASS_ROOT}/index.json`;
      const response = await fetch(indexPath);
      
      if (!response.ok) {
        console.warn("EQRMSS | Class index not found", indexPath);
        return [];
      }
      
      const index = await response.json();
      const names = Array.isArray(index?.classes) ? index.classes : [];
      const classes = [];

      for (const name of names) {
        if (!name) continue;
        const path = `${CLASS_ROOT}/${name}.json`;
        
        try {
          const classResponse = await fetch(path);
          if (!classResponse.ok) {
            console.warn("EQRMSS | Class file not found", path);
            continue;
          }
          const data = normalizeClassDefinition(await classResponse.json());
          if (!data) continue;
          classes.push(data);
        } catch (error) {
          console.error(`EQRMSS | Failed loading class ${name}`, error);
        }
      }

      // Initialize containers 
      CONFIG.EQRMSS ??= {};
      const cfg = CONFIG.EQRMSS;
      cfg.classes = Object.fromEntries(classes.map(c => [c.id ?? c.key ?? c.name, c]));

      // Consolidated maps 
      cfg.abilities = cfg.abilities ?? {};
      cfg['ability-profiles'] = cfg['ability-profiles'] ?? {};
      cfg['combat-profiles'] = cfg['combat-profiles'] ?? {};
      cfg.disciplines = cfg.disciplines ?? {};
      cfg.features = cfg.features ?? {};
      cfg['pet-profiles'] = cfg['pet-profiles'] ?? {};
      cfg.progressions = cfg.progressions ?? {};
      cfg['skill-profiles'] = cfg['skill-profiles'] ?? {};
      cfg['song-profiles'] = cfg['song-profiles'] ?? {};
      cfg['spell-profiles'] = cfg['spell-profiles'] ?? {};

      // Populate consolidated maps from each class file 
      for (const cls of classes) {
        const cid = cls.id ?? cls.key ?? cls.name ?? Symbol('unknown');

        // abilities: object of id->ability or array 
        if (cls.abilities) {
          if (Array.isArray(cls.abilities)) {
            for (const a of cls.abilities) put(cfg.abilities, a.id ?? a.key ?? a.name, a);
          } else if (typeof cls.abilities === 'object') {
            for (const [k, v] of Object.entries(cls.abilities)) put(cfg.abilities, k, v);
          }
        }

        // generic profiles/collections helper
        const copyIfPresent = (prop, targetKey, transform) => {
          const val = cls[prop];
          if (!val) return;
          if (Array.isArray(val)) {
            for (const item of val) {
              put(cfg[targetKey], (item.id ?? item.key ?? item.name), transform ? transform(item) : item);
            }
          } else if (typeof val === 'object') {
            for (const [k, v] of Object.entries(val)) {
              put(cfg[targetKey], k, transform ? transform(v) : v);
            }
          }
        };

        // Populate standard profile collections mapped across classes
        copyIfPresent('abilityProfiles', 'ability-profiles');
        copyIfPresent('combatProfiles', 'combat-profiles');
        copyIfPresent('disciplines', 'disciplines');
        copyIfPresent('features', 'features');
        copyIfPresent('petProfiles', 'pet-profiles');
        copyIfPresent('progressions', 'progressions', (prog) => ({ ...prog, class: cid }));
        copyIfPresent('skillProfiles', 'skill-profiles');
        copyIfPresent('songProfiles', 'song-profiles');
        copyIfPresent('spellProfiles', 'spell-profiles');
      }

      console.info("EQRMSS | Classes loaded", classes.length);
      return classes;

    } catch (error) {
      console.error("EQRMSS | Failed to load classes", error);
      CONFIG.EQRMSS ??= {};
      CONFIG.EQRMSS.classes ??= {};
      return [];
    }
  }
}

// ============================================================
// PUBLIC API
// ============================================================

export async function loadClasses() {
  return await ClassLoader.load();
}

// ============================================================
// LEGACY COMPATIBILITY
// ============================================================

export async function loadEQRMSSClasses() {
  return await ClassLoader.load();
}

export default ClassLoader;