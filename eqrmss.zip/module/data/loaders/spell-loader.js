// ============================================================
// EQRMSS Spell Loader
//
// Foundry VTT V13 / V14
//
// Directory-driven spell loading.
//
// PUBLIC API
//
//     loadSpells()
//
// COMPATIBILITY
//
//     loadEQRMSSpells()
// ============================================================

const SPELL_ROOT =
    "systems/eqrmss/module/data/spells";


const SPELL_CLASSES = [

    "beastlord",
    "cleric",
    "druid",
    "enchanter",
    "magician",
    "necromancer",
    "paladin",
    "ranger",
    "shadowknight",
    "shaman",
    "wizard"

];


const SPELL_TIERS = [

    "01_10",
    "11_20",
    "21_30",
    "31_40",
    "41_50",
    "51_60"

];


// ============================================================
// LOAD SPELLS
// ============================================================

export async function loadSpells()
{
    const spellsByClass = {};
    const allSpells = [];


    for (const className of SPELL_CLASSES)
    {
        const spells =
            await loadClassSpells(
                className
            );


        spellsByClass[className] =
            spells;


        allSpells.push(
            ...spells
        );
    }


    CONFIG.EQRMSS ??= {};


    CONFIG.EQRMSS.spells ??=
    {
        all: [],
        byClass: {}
    };


    CONFIG.EQRMSS.spells.all =
        allSpells;


    CONFIG.EQRMSS.spells.byClass =
        spellsByClass;


    console.info(
        "EQRMSS | Spells loaded",
        {
            classes:
                SPELL_CLASSES.length,

            total:
                allSpells.length
        }
    );


    return allSpells;
}


// ============================================================
// LOAD ONE CLASS
// ============================================================

async function loadClassSpells(
    className
)
{
    const spells = [];


    for (const tier of SPELL_TIERS)
    {
        const path =
            `${SPELL_ROOT}/${className}/spells_${tier}.json`;


        try
        {
            const response =
                await fetch(path);


            if (!response.ok)
                continue;


            const list =
                await response.json();


            if (!Array.isArray(list))
                continue;


            for (const spell of list)
            {
                if (!spell)
                    continue;


                if (
                    !spell.icon
                    &&
                    spell.id
                )
                {
                    spell.icon =
                        `systems/eqrmss/assets/Icons/spells/${spell.id}.png`;
                }


                spells.push(
                    spell
                );
            }

        }
        catch (error)
        {
            console.warn(
                "EQRMSS | Failed to load spell tier",
                {
                    className,
                    tier,
                    error
                }
            );
        }
    }


    return spells;
}


// ============================================================
// LEGACY COMPATIBILITY EXPORT
// ============================================================

export async function loadEQRMSSpells()
{
    return loadSpells();
}


// ============================================================
// DEFAULT
// ============================================================

export default loadSpells;

// ============================================================
// STANDARDIZED LOADER API (for register-data-loaders.js)
// ============================================================

export const SpellLoader = {
    async load() {
        return loadSpells();
    }
};
