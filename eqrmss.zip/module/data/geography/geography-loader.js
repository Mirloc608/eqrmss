/* ============================================================
 * EQRMSS Geography Loader
 * EverQuest - Rolemaster Standard System
 * Foundry VTT V13 / V14 Compatible
 * ============================================================
 */

export const EQRMSSGeography = {
    /** In‑memory geography cache: continents → regions → zones → files */
    data: {},

    /** Prevent overlapping simultaneous geography reloads */
    _loadPromise: null,

    /** Quick access helpers */
    get continents() {
        return Object.keys(this.data);
    },

    getRegions(continent) {
        return this.data[continent] ? Object.keys(this.data[continent]) : [];
    },

    getZones(continent, region) {
        const r = this.data[continent]?.[region];
        if (!r) return [];
        return Object.keys(r).filter(k => typeof r[k] === "object" && !k.endsWith(".json"));
    },

    getRegionManifest(continent, region) {
        return this.data[continent]?.[region]?.["bazaar-region"] // example
            ?? this.data[continent]?.[region]?.[`${region}-region`]
            ?? null;
    },

    getZoneManifest(continent, region, zone) {
        return this.data[continent]?.[region]?.[zone]?.[zone] ?? null;
    },

    /** Main entry: load all geography into memory */
    async loadAll() {
        if (this._loadPromise) {
            console.log("EQRMSS | Geography | loadAll already in progress; waiting for active load");
            return this._loadPromise;
        }

        this._loadPromise = (async () => {
            console.log("EQRMSS | Geography | Starting loadAll()");
            const basePath = "systems/eqrmss/module/data/geography";

            this.data = {};

            try {
                const continents = await this._browseSafe(basePath);
                for (const continentPath of continents.dirs) {
                    const continentName = continentPath.split("/").pop();
                    await this._loadContinent(basePath, continentName);
                }

                // Expose on game.eqrmss
                game.eqrmss = game.eqrmss || {};
                game.eqrmss.geography = this;

                console.log("EQRMSS | Geography | Loaded continents:", this.continents);
                return this.data;
            } catch (err) {
                console.error("EQRMSS | Geography | Fatal load error", err);
                ui.notifications?.error("EQRMSS Geography failed to load. Check console.");
                throw err;
            } finally {
                this._loadPromise = null;
            }
        })();

        return this._loadPromise;
    },

    /* ------------------------------------------------------------
     * Internal: load a continent
     * ---------------------------------------------------------- */
    async _loadContinent(basePath, continentName) {
        console.log(`EQRMSS | Geography | Loading continent: ${continentName}`);
        this.data[continentName] = {};

        const continentPath = `${basePath}/${continentName}`;
        const regions = await this._browseSafe(continentPath);

        for (const regionPath of regions.dirs) {
            const regionName = regionPath.split("/").pop();
            await this._loadRegion(continentName, continentPath, regionName);
        }
    },

    /* ------------------------------------------------------------
     * Internal: load a region (including its zones)
     * ---------------------------------------------------------- */
    async _loadRegion(continentName, continentPath, regionName) {
        console.log(`EQRMSS | Geography | Loading region: ${continentName}/${regionName}`);
        this.data[continentName][regionName] = {};

        const regionPath = `${continentPath}/${regionName}`;
        const regionBrowse = await this._browseSafe(regionPath);

        // Region‑level JSON files (the 18‑file set at region scope)
        for (const file of regionBrowse.files) {
            if (!file.endsWith(".json")) continue;
            const fileName = file.split("/").pop().replace(".json", "");
            const json = await this._fetchSafe(file, `region ${regionName} file ${fileName}`);
            if (!json) continue;
            this.data[continentName][regionName][fileName] = json;
        }

        // Zone folders (each with its own 18‑file set)
        for (const zoneFolder of regionBrowse.dirs) {
            const zoneName = zoneFolder.split("/").pop();
            await this._loadZone(continentName, regionName, zoneFolder, zoneName);
        }
    },

    /* ------------------------------------------------------------
     * Internal: load a zone (18‑file package)
     * ---------------------------------------------------------- */
    async _loadZone(continentName, regionName, zoneFolder, zoneName) {
        console.log(`EQRMSS | Geography | Loading zone: ${continentName}/${regionName}/${zoneName}`);
        this.data[continentName][regionName][zoneName] = {};

        const zoneBrowse = await this._browseSafe(zoneFolder);

        for (const file of zoneBrowse.files) {
            if (!file.endsWith(".json")) continue;
            const fileName = file.split("/").pop().replace(".json", "");
            const json = await this._fetchSafe(file, `zone ${zoneName} file ${fileName}`);
            if (!json) continue;
            this.data[continentName][regionName][zoneName][fileName] = json;
        }
    },

    /* ------------------------------------------------------------
     * Safe wrappers around FilePicker.browse and fetch
     * ---------------------------------------------------------- */
    async _browseSafe(path) {
        try {
            const FilePickerImpl = foundry?.applications?.apps?.FilePicker?.implementation ?? globalThis.FilePicker;
            if (!FilePickerImpl) {
                console.warn(`EQRMSS | Geography | FilePicker API unavailable for path: ${path}`);
                return { dirs: [], files: [] };
            }
            return await FilePickerImpl.browse("data", path);
        } catch (err) {
            console.error(`EQRMSS | Geography | Failed to browse path: ${path}`, err);
            return { dirs: [], files: [] };
        }
    },

    async _fetchSafe(path, label) {
        try {
            const response = await fetch(path);
            if (!response.ok) {
                console.error(`EQRMSS | Geography | HTTP ${response.status} loading ${label} (${path})`);
                return null;
            }
            return await response.json();
        } catch (err) {
            console.error(`EQRMSS | Geography | Failed to fetch ${label} (${path})`, err);
            return null;
        }
    }
};
