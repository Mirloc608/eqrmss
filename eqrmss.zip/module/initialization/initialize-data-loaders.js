// ============================================================
// EQRMSS Data Loader Initialization
// Foundry V13/V14
// ============================================================

import { StatsLoader }       from "../data/loaders/stats-loader.js";
import { ClassLoader }       from "../data/loaders/class-loader.js";
import { RaceLoader }        from "../data/loaders/race-loader.js";
import { AbilityLoader }     from "../data/loaders/ability-loader.js";
import { FeatureLoader }     from "../data/loaders/feature-loader.js";
import { ProgressionLoader } from "../data/loaders/progression-loader.js";
import { SpellLoader }       from "../data/loaders/spell-loader.js";
import { SongLoader }        from "../data/loaders/song-loader.js";
import { OriginDataLoader }  from "../data/loaders/origin-loader.js";
import { SkillLoader }       from "../data/skills/skill-loader.js";
import { DisciplineLoader }  from "../data/loaders/discipline-loader.js";

// ------------------------------------------------------------
// NORMALIZATION
// ------------------------------------------------------------

function normalizeCollection(raw, name) {

  if (Array.isArray(raw)) return raw;

  if (!raw) return [];

  if (
    raw &&
    typeof raw === "object" &&
    Array.isArray(raw[name])
  ) {
    return raw[name];
  }

  return [];
}

// ------------------------------------------------------------
// MAIN LOADER
// ------------------------------------------------------------

export async function initializeEQRMSSDataLoaders() {

  console.log(
    "EQRMSS | Initializing data loaders"
  );

  game.eqrmss ??= {};

  // ==========================================================
  // Expansion Bootstrap Hook
  // ==========================================================
  //
  // The actual expansion subsystem will attach:
  //
  // game.eqrmss.expansions
  // game.eqrmss.expansionManager
  //
  // during startup.
  //
  // Do NOT initialize expansion files here until the
  // expansion subsystem exists in eqrmss-tree.
  // ==========================================================

  const activeExpansion =
    game.settings.get(
      "eqrmss",
      "activeExpansion"
    ) ?? "classic";

  console.log(
    `EQRMSS | Active Expansion: ${activeExpansion}`
  );

  const results = {};

  async function load(name, fn) {

    console.log(
      `EQRMSS | Loading data: ${name}`
    );

    try {

      const raw = await fn();

      // ------------------------------------------------------
      // Progression loader returns structured object
      // ------------------------------------------------------

      if (name === "progression") {

        results.progression = raw ?? {
          classes: {},
          levels: {},
          skills: {},
          abilities: {}
        };

        console.log(
          "EQRMSS | Loaded progression (object)"
        );

        return;
      }

      // ------------------------------------------------------
      // Origin loader returns structured object
      // ------------------------------------------------------

      if (name === "origin") {

        results.origin = {
          cities: raw?.cities ?? [],
          deities: raw?.deities ?? [],
          factions: raw?.factions ?? [],
          languages: raw?.languages ?? []
        };

        console.log(
          "EQRMSS | Loaded origin",
          {
            cities:
              results.origin.cities.length,

            deities:
              results.origin.deities.length,

            factions:
              results.origin.factions.length,

            languages:
              results.origin.languages.length
          }
        );

        return;
      }

      const normalized =
        normalizeCollection(
          raw,
          name
        );

      results[name] = normalized;

      console.log(
        `EQRMSS | Loaded ${name} (${normalized.length})`
      );

    }
    catch (error) {

      console.error(
        `EQRMSS | Failed loading ${name}`,
        error
      );

      if (name === "origin") {

        results.origin = {
          cities: [],
          deities: [],
          factions: [],
          languages: []
        };
      }
      else if (name === "progression") {

        results.progression = {
          classes: {},
          levels: {},
          skills: {},
          abilities: {}
        };
      }
      else {

        results[name] = [];
      }
    }
  }

  // ----------------------------------------------------------
  // Core Data
  // ----------------------------------------------------------

  await load("stats", StatsLoader.load);
  await load("classes", ClassLoader.load);
  await load("races", RaceLoader.load);
  await load("abilities", AbilityLoader.load);
  await load("skills", SkillLoader.load);
  await load("features", FeatureLoader.load);
  await load("progression", ProgressionLoader.load);

  // ----------------------------------------------------------
  // Magic / Discipline Data
  // ----------------------------------------------------------

  await load("spells", SpellLoader.load);
  await load("songs", SongLoader.load);
  await load("disciplines", DisciplineLoader.load);

  // ----------------------------------------------------------
  // Origin Data
  // ----------------------------------------------------------

  await load("origin", OriginDataLoader.load);

  // ----------------------------------------------------------
  // CONFIG Registration
  // ----------------------------------------------------------

  CONFIG.EQRMSS ??= {};

  CONFIG.EQRMSS.data = {
    loaded: true,

    activeExpansion,

    results
  };

  console.log(
    "EQRMSS | Data loading complete",
    {
      activeExpansion,

      races:
        results.races?.length ?? 0,

      classes:
        results.classes?.length ?? 0,

      cities:
        results.origin?.cities?.length ?? 0,

      deities:
        results.origin?.deities?.length ?? 0,

      spells:
        results.spells?.length ?? 0,

      songs:
        results.songs?.length ?? 0,

      disciplines:
        results.disciplines?.length ?? 0
    }
  );

  return results;
}

export default initializeEQRMSSDataLoaders;