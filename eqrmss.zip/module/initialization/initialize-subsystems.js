// ============================================================
// EQRMSS Subsystem Initialization
// ============================================================

import { EQRMSSCharacterCreationWizard }
  from "../apps/eqrmss-character-creation-wizard.js";

import { initializePetsSubsystem }
  from "../pets/pets-subsystem.js";

import {
  EQRMSSExpansionLoader
} from "../expansion/expansion-loader.js";

import {
  EQRMSSExpansionRegistry
} from "../expansion/expansion-registry.js";

import {
  EQRMSSExpansionManager
} from "../expansion/expansion-manager.js";

export async function initializeEQRMSSSubsystems() {

  console.info(
    "EQRMSS | Initializing subsystems"
  );

  game.eqrmss =
    game.eqrmss || {};

  game.eqrmss.subsystems =
    game.eqrmss.subsystems || {};

  // ==========================================================
  // Expansion System
  // ==========================================================

  const expansions =
    await EQRMSSExpansionLoader.loadAll();

  game.eqrmss.expansions =
    EQRMSSExpansionRegistry;

  game.eqrmss.expansionManager =
    EQRMSSExpansionManager;

  console.info(
    `EQRMSS | Loaded ${expansions.length} expansions`
  );

  // ==========================================================
  // Character Creation Wizard
  // ==========================================================

  game.eqrmss.subsystems.characterWizard =
    new EQRMSSCharacterCreationWizard({
      data: game.eqrmss.data
    });

  // ==========================================================
  // Pets
  // ==========================================================

  await initializePetsSubsystem();

  console.info(
    "EQRMSS | Subsystems initialized"
  );
}